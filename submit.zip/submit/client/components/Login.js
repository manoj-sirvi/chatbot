import React, { useState } from 'react';
import axios from 'axios';

const LoginPage = ({ onLogin, workflows }) => {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState('');

  const handleInputChange = (event) => {
    setUsername(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (username.trim()) {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.post('http://localhost:5000/api/chat/start', { username });
        onLogin(username, response.data.conversationId, response.data.message,response.data.workflows);
        setIsLoggedIn(true);
      } catch (err) {
        console.error('Error starting chat:', err);
        setError('Could not start chat. Please try again.');
      } finally {
        setLoading(false);
      }
    } else {
      alert('Please enter your name.');
    }
  };

  const handleWorkflowChange = (event) => {
    setSelectedWorkflow(event.target.value);
  };

  const styles = {
    loginContainer: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      background: 'linear-gradient(to right, #74ebd5, #acb6e5)',
      padding: '20px',
    },
    heading: {
      marginBottom: '25px',
      fontSize: '28px',
      color: '#ffffff',
    },
    form: {
      backgroundColor: '#ffffff',
      padding: '30px',
      borderRadius: '10px',
      boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
      width: '100%',
      maxWidth: '350px',
    },
    inputGroup: {
      marginBottom: '20px',
    },
    label: {
      display: 'block',
      marginBottom: '8px',
      fontWeight: 'bold',
      color: '#333',
      fontSize: '15px',
    },
    input: {
      width: '100%',
      padding: '10px',
      border: '1px solid #ccc',
      borderRadius: '6px',
      fontSize: '16px',
      outline: 'none',
    },
    button: {
      width: '100%',
      padding: '12px',
      backgroundColor: '#007bff',
      color: 'white',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '16px',
      transition: 'background-color 0.3s ease',
    },
    buttonDisabled: {
      backgroundColor: '#b0c4de',
      cursor: 'not-allowed',
    },
    error: {
      color: '#dc3545',
      marginTop: '15px',
      textAlign: 'center',
    },
    dropdown: {
      width: '100%',
      padding: '10px',
      border: '1px solid #ccc',
      borderRadius: '6px',
      fontSize: '16px',
      marginTop: '15px',
    },
  };

  const isButtonDisabled = !username.trim() || loading;

  return (
    <div style={styles.loginContainer}>
      {!isLoggedIn ? (
        <>
          <h2 style={styles.heading}>🚀 Welcome to the Chatbot!</h2>
          <form style={styles.form} onSubmit={handleSubmit}>
            <div style={styles.inputGroup}>
              <label htmlFor="username" style={styles.label}>
                Your Name:
              </label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={handleInputChange}
                placeholder="e.g. Alex"
                style={styles.input}
                disabled={loading}
                autoFocus
              />
            </div>
            <button
              type="submit"
              disabled={isButtonDisabled}
              style={{
                ...styles.button,
                ...(isButtonDisabled && styles.buttonDisabled),
              }}
            >
              {loading ? 'Starting Chat...' : 'Start Chatting'}
            </button>
            {error && <p style={styles.error}>{error}</p>}
          </form>
        </>
      ) : (
        <div style={styles.form}>
          <h2 style={styles.heading}>Welcome, {username}!</h2>
          <label htmlFor="workflow" style={styles.label}>
            Select Workflow:
          </label>
          <select
            id="workflow"
            value={selectedWorkflow}
            onChange={handleWorkflowChange}
            style={styles.dropdown}
          >
            <option value="">-- Choose Workflow --</option>
            {workflows && workflows.length > 0 ? (
              workflows.map((workflow, index) => (
                <option key={index} value={workflow.id}>
                  {workflow.name}
                </option>
              ))
            ) : (
              <option disabled>No workflows available</option>
            )}
          </select>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
