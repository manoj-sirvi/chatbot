import React, { useState, useEffect } from 'react';
import LoginPage from './components/Login';
import ChatPage from './components/ChatPage';
import WorkflowBuilder from './components/xyz';
import axios from 'axios';

function App() {
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [conversationId, setConversationId] = useState(null);
  const [welcomeMessage, setWelcomeMessage] = useState(null);
  const [showWorkflowBuilder, setShowWorkflowBuilder] = useState(false);
  const [availableWorkflows, setAvailableWorkflows] = useState([]);
  // const [workflows,setWorkFlows] = useState([])

  const fetchAvailableWorkflows = async () => {
    try {
      const response = await axios.get('/api/workflows');
      setAvailableWorkflows(response.data);
    } catch (error) {
      console.error('Error fetching workflows:', error);
    }
  };

  useEffect(() => {
    fetchAvailableWorkflows();
  }, []);
  const handleLogin = (username, id, message, workflows) => {
    setLoggedInUser(username);
    setConversationId(id);
    setWelcomeMessage(message);
    setAvailableWorkflows(workflows)
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    setConversationId(null);
    setWelcomeMessage(null);
    setShowWorkflowBuilder(false);
    setAvailableWorkflows([]);
  };

  const toggleWorkflowBuilder = () => {
    setShowWorkflowBuilder(!showWorkflowBuilder);
  };

  const handleWorkflowSaved = async () => {
    await fetchAvailableWorkflows();
    setShowWorkflowBuilder(false);
  };

    return (
      <div className="app-container">
        <h1>Chatbot</h1>

        {!loggedInUser ? (
          <div className="login-section">
            <LoginPage onLogin={handleLogin} />
          </div>
        ) : (
          <div className="dashboard">
            <div className="top-bar">
              <span className="user-info">Logged in as <strong>{loggedInUser}</strong></span>
              <div className="button-group">
  <button className="logout-button" onClick={handleLogout}>Logout</button>
  <button className="workflow-toggle-button" onClick={toggleWorkflowBuilder}>
    {showWorkflowBuilder ? 'Hide Workflow Builder' : 'Show Workflow Builder'}
  </button>
</div>

            </div>

            <div className="main-content">
              {showWorkflowBuilder ? (
                <WorkflowBuilder onWorkflowSaved={handleWorkflowSaved} />
              ) : (
                <ChatPage
                  username={loggedInUser}
                  conversationId={conversationId}
                  initialMessage={welcomeMessage}
                  workflows={availableWorkflows}
                />
              )}
            </div>
          </div>
        )}
      </div>
    );
}

export default App;