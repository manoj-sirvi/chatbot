// Update the React import at the top of the file
import { useState, useCallback, useEffect } from 'react';
import axios from 'axios';
import ReactFlow, {
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  addEdge,
  Controls,
  Background,
  useReactFlow,
  MarkerType,
  Handle,
  Position
} from 'reactflow';
import 'reactflow/dist/style.css';


const MessageNode = ({ id, data }) => {
  const handleImageUpload = useCallback((event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        data.onContentChange(id, e.target.result);
      };
      reader.readAsDataURL(file);
    }
  }, [id, data.onContentChange]);

  return (
    <div className="message-node">
      <Handle type="target" position={Position.Left} />
      <div className="node-header">
        <span className="node-icon">📩</span>
        <span className="node-title">Message</span>
      </div>

      <select
        value={data.messageType}
        onChange={(e) => data.onMessageTypeChange?.(id, e.target.value)}
        className="node-select"
      >
        <option value="text">Text</option>
        <option value="button">Button</option>
        <option value="image">Image</option>
      </select>

      {data.messageType === 'text' && (
        <textarea
          value={data.content}
          onChange={(e) => data.onContentChange?.(id, e.target.value)}
          placeholder="Type message..."
          className="node-textarea"
        />
      )}

      {data.messageType === 'button' && (
        <div className="button-options">
          {data.buttons?.map((button, index) => (
            <div key={index} className="button-item">
              <input
                type="text"
                placeholder="Button text"
                value={button.label}
                onChange={(e) => data.onButtonLabelChange?.(id, index, e.target.value)}
              />
              <input
                type="text"
                placeholder="Button action"
                value={button.action}
                onChange={(e) => data.onButtonActionChange?.(id, index, e.target.value)}
              />
              <button
                className="remove-button"
                onClick={() => data.onRemoveButton?.(id, index)}
              >
                ×
              </button>
            </div>
          ))}
          <button
            className="add-button"
            onClick={() => data.onAddButton?.(id)}
          >
            Add Button
          </button>
        </div>
      )}

      {data.messageType === 'image' && (
        <div className="image-upload">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="file-input"
          />
          {data.content && (
            <img
              src={data.content}
              alt="Upload preview"
              className="image-preview"
            />
          )}
        </div>
      )}

      <Handle type="source" position={Position.Right} />
    </div>
  );
};
const nodeTypes = {
  start: () => (
    <div className="start-node">
      <div className="node-icon">🔵</div>
      <div className="node-title">Start</div>
      <Handle type="source" position={Position.Right} />
    </div>
  ),

  message: MessageNode,

  action: ({ id, data }) => (
    <div className="action-node">
      <Handle type="target" position={Position.Left} />
      <div className="node-header">
        <span className="node-icon">⚡</span>
        <span className="node-title">Action</span>
      </div>
      <select
        value={data.actionType}
        onChange={(e) => data.onActionTypeChange(id, e.target.value)}
        className="node-select"
      >
        <option value="redirect">Redirect</option>
        <option value="notification">Notification</option>
        <option value="email">Email</option>
      </select>
      <input
        type="text"
        value={data.actionTarget}
        onChange={(e) => data.onActionTargetChange(id, e.target.value)}
        placeholder="Target URL/Email..."
        className="node-input"
      />
      <Handle type="source" position={Position.Right} />
    </div>
  ),

  filter: ({ id, data }) => (
    <div className="filter-node">
      <Handle type="target" position={Position.Left} />
      <div className="node-header">
        <span className="node-icon">🎚️</span>
        <span className="node-title">Filter</span>
      </div>
      <select
        value={data.filterType}
        onChange={(e) => data.onFilterTypeChange(id, e.target.value)}
        className="node-select"
      >
        <option value="content">Content</option>
        <option value="user">User</option>
        <option value="time">Time</option>
      </select>
      <input
        type="text"
        value={data.condition}
        onChange={(e) => data.onConditionChange(id, e.target.value)}
        placeholder="Condition..."
        className="node-input"
      />
      <Handle type="source" position={Position.Right} />
    </div>
  ),

  api: ({ id, data }) => (
    <div className="api-node">
      <Handle type="target" position={Position.Left} />
      <div className="node-header">
        <span className="node-icon">🌐</span>
        <span className="node-title">API Request</span>
      </div>
      <select
        value={data.method}
        onChange={(e) => data.onMethodChange(id, e.target.value)}
        className="node-select"
      >
        <option value="GET">GET</option>
        <option value="POST">POST</option>
        <option value="PUT">PUT</option>
        <option value="DELETE">DELETE</option>
      </select>
      <input
        type="text"
        value={data.endpoint}
        onChange={(e) => data.onEndpointChange(id, e.target.value)}
        placeholder="API Endpoint..."
        className="node-input"
      />
      <textarea
        value={data.payload}
        onChange={(e) => data.onPayloadChange(id, e.target.value)}
        placeholder="Request Payload..."
        className="node-textarea"
      />
      <Handle type="source" position={Position.Right} />
    </div>
  )
};

const FlowBuilder = () => {
  const { project } = useReactFlow();
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [workflowName, setWorkflowName] = useState('');
  const [existingWorkflows, setExistingWorkflows] = useState([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState('');

  const handleAddButton = useCallback((id) => {
    setNodes(nodes => nodes.map(node => {
      if (node.id === id) {
        return {
          ...node,
          data: {
            ...node.data,
            buttons: [...(node.data.buttons || []), { label: '', action: '' }]
          }
        };
      }
      return node;
    }));
  }, []);

  const handleRemoveButton = useCallback((id, index) => {
    setNodes(nodes => nodes.map(node => {
      if (node.id === id) {
        return {
          ...node,
          data: {
            ...node.data,
            buttons: node.data.buttons.filter((_, i) => i !== index)
          }
        };
      }
      return node;
    }));
  }, []);

  const handleButtonLabelChange = useCallback((id, index, value) => {
    setNodes(nodes => nodes.map(node => {
      if (node.id === id) {
        const newButtons = [...node.data.buttons];
        newButtons[index].label = value;
        return {
          ...node,
          data: { ...node.data, buttons: newButtons }
        };
      }
      return node;
    }));
  }, []);

  const handleButtonActionChange = useCallback((id, index, value) => {
    setNodes(nodes => nodes.map(node => {
      if (node.id === id) {
        const newButtons = [...node.data.buttons];
        newButtons[index].action = value;
        return {
          ...node,
          data: { ...node.data, buttons: newButtons }
        };
      }
      return node;
    }));
  }, []);
  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge({
      ...params,
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: '#ff0072',
        width: 20,
        height: 20
      },
      style: { stroke: '#ff0072', strokeWidth: 2 }
    }, eds)),
    [setEdges]
  );

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/workflows');
      setExistingWorkflows(response.data.workflows);
    } catch (error) {
      console.error('Error fetching workflows:', error);
    }
  };

  // Save/Update Workflow
  const saveWorkflow = async () => {
    if (!workflowName) {
      alert('Please enter a workflow name');
      return;
    }

    try {
      const flowData = {
        nodes,
        edges
      };

      const response = await axios.post('http://localhost:5000/api/save-workflow', {
        name: workflowName,
        data: flowData
      });

      alert(response.data.message);
      fetchWorkflows();
    } catch (error) {
      alert(error.response?.data?.error || 'Error saving workflow');
    }
  };

  const loadWorkflow = async (workflowName) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/workflows/${workflowName}`);
      const nodes = response.data.nodes.map(node => {
        const base = {
          id: node.id,
          type: node.type,
          position: node.position,
          data: {
            ...node.data,
            // Message node handlers
            onMessageTypeChange: handleMessageTypeChange,
            onContentChange: handleContentChange,
            // Action node handlers
            onActionTypeChange: handleActionTypeChange,
            onActionTargetChange: handleActionTargetChange,
            onFilterTypeChange: handleFilterTypeChange,
            onConditionChange: handleConditionChange,
            onMethodChange: handleMethodChange,
            onEndpointChange: handleEndpointChange,
            onPayloadChange: handlePayloadChange,

            onMessageTypeChange: handleMessageTypeChange,
            onContentChange: handleContentChange,
            onAddButton: handleAddButton,
            onRemoveButton: handleRemoveButton,
            onButtonLabelChange: handleButtonLabelChange,
            onButtonActionChange: handleButtonActionChange,
          }
        };
        return base;
      });

      setNodes(nodes);
      setEdges(response.data.edges);
      setSelectedWorkflow(workflowName);

      alert('Workflow loaded successfully!');
    } catch (error) {
      alert(`Error loading workflow: ${error.response?.data?.error || error.message}`);
    }
  };

  // Delete Workflow
  const deleteWorkflow = async (name) => {
    if (!window.confirm(`Delete workflow "${name}" permanently?`)) return;

    try {
      await axios.delete(`http://localhost:5000/api/workflows/${name}`);
      alert('Workflow deleted successfully');
      setWorkflowName('');
      setNodes([]);
      setEdges([]);
      fetchWorkflows();
    } catch (error) {
      alert(error.response?.data?.error || 'Error deleting workflow');
    }
  };

  // Node update handlers

  const handleActionTypeChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, actionType: value } } : node
    ));
  }, []);

  const handleActionTargetChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, actionTarget: value } } : node
    ));
  }, []);

  const handleFilterTypeChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, filterType: value } } : node
    ));
  }, []);

  const handleConditionChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, condition: value } } : node
    ));
  }, []);

  const handleMethodChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, method: value } } : node
    ));
  }, []);

  const handleEndpointChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, endpoint: value } } : node
    ));
  }, []);

  const handlePayloadChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, payload: value } } : node
    ));
  }, []);
  const handleMessageTypeChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, messageType: value } } : node
    ));
  }, []);

  const handleContentChange = useCallback((id, value) => {
    setNodes(nodes => nodes.map(node =>
      node.id === id ? { ...node, data: { ...node.data, content: value } } : node
    ));
  }, []);

  // Drag & Drop with proper positioning
  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const type = event.dataTransfer.getData('application/reactflow');
      const label = event.dataTransfer.getData('label');

      const position = project({
        x: event.clientX - 100,
        y: event.clientY - 40,
      });

      const baseData = {
        onMessageTypeChange: handleMessageTypeChange,
        onContentChange: handleContentChange,
        onActionTypeChange: handleActionTypeChange,
        onActionTargetChange: handleActionTargetChange,
        onFilterTypeChange: handleFilterTypeChange,
        onConditionChange: handleConditionChange,
        onMethodChange: handleMethodChange,
        onEndpointChange: handleEndpointChange,
        onPayloadChange: handlePayloadChange,
        onAddButton: handleAddButton,
        onRemoveButton: handleRemoveButton,
        onButtonLabelChange: handleButtonLabelChange,
        onButtonActionChange: handleButtonActionChange
      };

      const typeSpecificData = {
        start: {},
        message: { messageType: 'text', content: '' },
        action: { actionType: 'redirect', actionTarget: '' },
        filter: { filterType: 'content', condition: '' },
        api: { method: 'GET', endpoint: '', payload: '' }
      }[type];

      const newNode = {
        id: `${Date.now()}`,
        type,
        position,
        data: { ...baseData, ...typeSpecificData }
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [project, setNodes, handleMessageTypeChange, handleContentChange, handleActionTypeChange, handleActionTargetChange, handleFilterTypeChange, handleConditionChange, handleMethodChange, handleEndpointChange, handlePayloadChange]
  );

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <aside className="sidebar">
        <div className="description">Drag these nodes:</div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'start');
          e.dataTransfer.setData('label', 'Start');
        }}>
          🔵 Start
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'message');
          e.dataTransfer.setData('label', 'Message');
        }}>
          📩 Message
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'action');
          e.dataTransfer.setData('label', 'Action');
        }}>
          ⚡ Action
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'filter');
          e.dataTransfer.setData('label', 'Filter');
        }}>
          🎚️ Filter
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'api');
          e.dataTransfer.setData('label', 'API');
        }}>
          🌐 API
        </div>
      </aside>
      <div className="workflow-manager">
  <div className="workflow-controls">
    <input
      type="text"
      value={workflowName}
      onChange={(e) => setWorkflowName(e.target.value)}
      placeholder="Workflow name"
    />
    <button onClick={saveWorkflow}>
      {existingWorkflows.includes(workflowName) ? 'Update' : 'Save'}
    </button>

    <select
      onChange={(e) => setWorkflowName(e.target.value)}
      value={workflowName}
    >
      <option value="">Load Existing</option>
      {existingWorkflows.map((name) => (
        <option key={name} value={name}>
          {name}
        </option>
      ))}
    </select>

    {workflowName && (
      <button
        className="delete-btn"
        onClick={() => deleteWorkflow(workflowName)}
      >
        Delete
      </button>
    )}
  </div>
</div>
<div></div>
<div className="workflow-controls">
  <input
    type="text"
    value={selectedWorkflow}
    onChange={(e) => setSelectedWorkflow(e.target.value)}
    placeholder="Enter workflow name"
  />

  <button
    onClick={() => loadWorkflow(selectedWorkflow)}
    disabled={!selectedWorkflow}
  >
    Load Workflow
  </button>

  <select
    onChange={(e) => setSelectedWorkflow(e.target.value)}
    value={selectedWorkflow}
  >
    <option value="">Select existing workflow</option>
    {existingWorkflows.map((name) => (
      <option key={name} value={name}>{name}</option>
    ))}
  </select>
</div>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={{
          markerEnd: { type: MarkerType.ArrowClosed, color: '#ff0072' },
          style: { stroke: '#ff0072', strokeWidth: 2 }
        }}
        fitView
      >
        <Controls />
        <Background />
        <defs>
          <marker
            id="arrow-red"
            viewBox="0 0 20 20"
            refX="11"
            refY="10"
            markerWidth="10"
            markerHeight="10"
            orient="auto"
          >
            <path d="M 0 0 L 20 10 L 0 20 z" fill="#ff0072" />
          </marker>
        </defs>

        <div style={{ position: 'absolute', right: 10, top: 10, zIndex: 1000 }}>
          <button onClick={saveWorkflow} style={{ padding: '10px 20px', background: '#ff0072', color: 'white', border: 'none', borderRadius: 5, cursor: 'pointer' }}>
            💾 Save Workflow
          </button>
        </div>
      </ReactFlow>

      <style jsx global>{`
        .react-flow__edge-path {
          stroke: #ff0072 !important;
          stroke-width: 2 !important;
        }

        .react-flow__handle {
          background: #ff0072;
          width: 12px;
          height: 12px;
          border: 2px solid white;
        }
          .sidebar .dndnode:first-child {
             margin-top: 20px;
               }

        .sidebar {
            position: fixed !important;
  top: 100px !important;
  left: 10px !important;
          z-index: 1000;
          background: white;
          padding: 20px;
          border-radius: 10px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .dndnode {
          padding: 12px 20px;
          margin: 10px 0;
          border: 2px dashed #666;
          border-radius: 5px;
          cursor: grab;
        }

        .node {
          background: white;
          padding: 15px;
          border-radius: 5px;
          box-shadow: 0 2px 5px rgba(0,0,0,0.1);
          min-width: 200px;
        }

        .node-header {
          font-weight: bold;
          margin-bottom: 10px;
        }

        select, textarea {
          width: 100%;
          padding: 8px;
          margin: 5px 0;
          border: 1px solid #ddd;
          border-radius: 4px;
        }
          .react-flow__edge-path {
    stroke: #ff0072 !important;
    stroke-width: 2 !important;
  }

  .react-flow__handle {
    background: #ff0072;
    width: 10px;
    height: 10px;
    border: 2px solid white;
  }

  .sidebar {
    position: absolute;
    left: 10px;
    top: 10px;
    z-index: 1000;
    background: #ffffff;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    width: 160px;
  }

  .dndnode {
    padding: 10px 15px;
    margin: 8px 0;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    cursor: grab;
    font-size: 0.85rem;
    background: #f8fafc;
    transition: all 0.2s;
  }

  .dndnode:hover {
    background: #f1f5f9;
    transform: scale(1.02);
  }

  .node {
    background: white;
    padding: 12px;
    border-radius: 6px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    min-width: 180px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell;
  }

  .node-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
    padding-bottom: 8px;
    border-bottom: 1px solid #e2e8f0;
  }

  .node-icon {
    font-size: 1.1rem;
  }

  .node-title {
    font-size: 0.75rem;
    font-weight: 600;
    color: #1e293b;
  }

  .node-select, .node-textarea {
    width: 100%;
    padding: 6px 8px;
    margin: 4px 0;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    font-size: 0.65rem;
    background: #ffffff;
    transition: border-color 0.2s;
  }

  .node-select:focus, .node-textarea:focus {
    outline: none;
    border-color: #94a3b8;
    box-shadow: 0 0 0 2px rgba(148, 163, 184, 0.1);
  }

  .node-textarea {
    min-height: 60px;
    resize: vertical;
    font-family: inherit;
  }

  .save-button button {
    padding: 8px 16px;
    font-size: 0.65rem;
    background: #ff0072;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: opacity 0.2s;
  }

  .save-button button:hover {
    opacity: 0.9;
  }

  /* Node type specific colors */
  .start-node { border-left: 4px solid #3b82f6; }
  .message-node { border-left: 4px solid #10b981; }
  .action-node { border-left: 4px solid #f59e0b; }
  .filter-node { border-left: 4px solid #8b5cf6; }
  .api-node { border-left: 4px solid #ef4444; }
      `}</style>
    </div>
  );
};

export default function App() {
  return (
    <ReactFlowProvider>
      <FlowBuilder />
    </ReactFlowProvider>
  );
}