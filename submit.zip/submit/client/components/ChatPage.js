import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const ChatPage = ({ username, conversationId, initialMessage, workflows }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [selectedWorkflowId, setSelectedWorkflowId] = useState('');
  const [workflowSelected, setWorkflowSelected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const chatContainerRef = useRef(null);

  useEffect(() => {
    if (initialMessage) {
      setMessages([{ sender: 'Bot', text: initialMessage }]);
    }
  }, [initialMessage]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    const message = newMessage;
    setMessages(prev => [...prev, { sender: 'User', text: message }]);
    setNewMessage('');
    setLoading(true);
    setError(null);

    try {
      const res = await axios.post('http://localhost:5000/api/chat/send', {
        username,
        conversationId,
        message,
        workflowId: selectedWorkflowId,
      });
      setMessages(prev => [...prev, { sender: 'Bot', text: res.data.response }]);
    } catch (err) {
      setMessages(prev => [...prev, { sender: 'Bot', text: 'Error sending message.' }]);
      setError('Message failed to send.');
    } finally {
      setLoading(false);
    }
  };

  const handleWorkflowChange = async (e) => {
    const selectedId = e.target.value;
    setSelectedWorkflowId(selectedId);
    setWorkflowSelected(true);
    setLoading(true);

    try {
      const res = await axios.post('http://localhost:5000/api/chat/send', {
        username,
        conversationId,
        message: '',
        workflowId: selectedId,
      });

      setMessages(prev => [
        ...prev,
        { sender: 'User', text: `Selected workflow ID: ${selectedId}` },
        { sender: 'Bot', text: res.data.response },
      ]);
    } catch (err) {
      setMessages(prev => [...prev, { sender: 'Bot', text: 'Failed to load workflow.' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSendMessage();
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      backgroundColor: '#f5f5f5',
      fontFamily: 'Arial, sans-serif',
    },
    header: {
      backgroundColor: '#007bff',
      color: 'white',
      padding: '16px',
      fontSize: '18px',
      textAlign: 'center',
    },
    chatArea: {
      flexGrow: 1,
      overflowY: 'auto',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
    },
    message: {
      maxWidth: '70%',
      padding: '12px 16px',
      borderRadius: '16px',
      fontSize: '15px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
    user: {
      backgroundColor: '#d1f5ff',
      alignSelf: 'flex-end',
      textAlign: 'right',
    },
    bot: {
      backgroundColor: '#ffffff',
      alignSelf: 'flex-start',
      textAlign: 'left',
    },
    inputArea: {
      display: 'flex',
      padding: '12px',
      borderTop: '1px solid #ccc',
      backgroundColor: '#fff',
    },
    input: {
      flex: 1,
      padding: '10px',
      border: '1px solid #ccc',
      borderRadius: '6px 0 0 6px',
      fontSize: '16px',
    },
    button: {
      padding: '10px 18px',
      backgroundColor: '#28a745',
      color: 'white',
      border: 'none',
      borderRadius: '0 6px 6px 0',
      cursor: 'pointer',
      fontSize: '16px',
    },
    disabledBtn: {
      backgroundColor: '#ccc',
      cursor: 'not-allowed',
    },
    select: {
      margin: '10px auto',
      padding: '10px',
      width: '80%',
      fontSize: '16px',
      borderRadius: '6px',
      border: '1px solid #ccc',
    },
    errorText: {
      textAlign: 'center',
      color: '#dc3545',
      fontSize: '14px',
    },
    loading: {
      textAlign: 'center',
      color: '#666',
      fontStyle: 'italic',
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>Chat with {username}</div>

      <div style={styles.chatArea} ref={chatContainerRef}>
        {messages.map((msg, i) => (
          <div
            key={i}
            style={{
              ...styles.message,
              ...(msg.sender.toLowerCase() === 'user' ? styles.user : styles.bot),
            }}
          >
            <strong>{msg.sender}:</strong> {msg.text}
          </div>
        ))}
        {loading && <div style={styles.loading}>Processing...</div>}
        {error && <div style={styles.errorText}>{error}</div>}
      </div>

      {!workflowSelected && (
        <select
          style={styles.select}
          defaultValue=""
          onChange={handleWorkflowChange}
        >
          <option value="" disabled>
            Select a workflow ID...
          </option>
          {workflows.map(wf => (
            <option key={wf.id} value={wf.id}>
              Workflow {wf.id}
            </option>
          ))}
        </select>
      )}

      {workflowSelected && (
        <div style={styles.inputArea}>
          <input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            style={styles.input}
            disabled={loading}
          />
          <button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || loading}
            style={{
              ...styles.button,
              ...(loading || !newMessage.trim() ? styles.disabledBtn : {}),
            }}
          >
            Send
          </button>
        </div>
      )}
    </div>
  );
};

export default ChatPage;
