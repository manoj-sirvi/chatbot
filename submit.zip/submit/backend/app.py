from flask import Flask, request, jsonify
from flask_cors import CORS
import uuid
import os
import json

app = Flask(__name__)
CORS(app)

CONVERSATIONS_DIR = "conversations"
os.makedirs(CONVERSATIONS_DIR, exist_ok=True)
WORKFLOWS_DIR = "workflows"
os.makedirs(WORKFLOWS_DIR, exist_ok=True)

def generate_conversation_filename(username, conversation_id):
  return os.path.join(CONVERSATIONS_DIR, f"{username}_{conversation_id}.txt")

def save_message(filename, sender, message):
  with open(filename, "a") as f:
    f.write(f"{sender}: {message}")

def load_workflow(workflow_id):
  workflow_file = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
  try:
    with open(workflow_file, "r") as f:
      return json.load(f)
  except FileNotFoundError:
    return None

def save_workflow(workflow_id, workflow_data):
  workflow_file = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
  with open(workflow_file, "w") as f:
    json.dump(workflow_data, f, indent=4)

def execute_workflow(workflow, user_message, conversation_context):
  bot_response = "I'm sorry, I don't understand."

  if workflow["id"] == "breakfast":
        if "order" in user_message.lower():
            bot_response = "Great! What would you like to order for breakfast?"
        elif "menu" in user_message.lower():
            bot_response = "Our breakfast menu has eggs, bacon, and toast."
        else:
            bot_response = "Good morning! How can I help you with breakfast?"

  elif workflow["id"] == "lunch":
        if "order" in user_message.lower():
            bot_response = "Sure, what would you like for lunch?"
        elif "menu" in user_message.lower():
            bot_response = "For lunch, we have sandwiches, salads, and soup."
        else:
            bot_response = "Hello! What can I get you for lunch today?"

  elif workflow["id"] == "dinner":
        if "order" in user_message.lower():
            bot_response = "Excellent choice! What would you like to order for dinner?"
        elif "menu" in user_message.lower():
            bot_response = "Our dinner menu includes steak, pasta, and fish."
        else:
            bot_response = "Welcome! Are you ready to order dinner?"

  return bot_response, conversation_context

@app.route('/api/chat/start', methods=['POST'])
def start_chat():
  data = request.get_json()
  username = data.get('username')
  if not username:
    return jsonify({"error": "Username is required"}), 400
  conversation_id = str(uuid.uuid4())
  conversation_file = generate_conversation_filename(username, conversation_id)

  workflows = []
  for filename in os.listdir(WORKFLOWS_DIR):
    if filename.endswith(".json"):
      workflow_id = filename[:-5]
      workflow = load_workflow(workflow_id)
      if workflow:
        workflows.append({"id": workflow_id})

  return jsonify({
    "message": "Welcome to the Chatbot!",
    "conversationId": conversation_id,
    "username": username,
    "conversationFile": conversation_file,
    "workflows": workflows,
  })

@app.route('/api/chat/send', methods=['POST'])
def send_message():
  data = request.get_json()
  conversation_id = data.get('conversationId')
  message = data.get('message')
  username = data.get('username')
  workflow_id = data.get("workflowId")
  print(workflow_id,username)

  conversation_file = generate_conversation_filename(username, conversation_id)
  save_message(conversation_file, "User", message)

  workflow = load_workflow(workflow_id)

  if workflow:
    conversation_context = []
    bot_response, _ = execute_workflow(workflow, message, conversation_context)
  else:
    bot_response = "Sorry, I'm having trouble processing that right now."

  save_message(conversation_file, "Bot", bot_response)
  print(bot_response)

  return jsonify({"response": bot_response})

@app.route('/api/workflows', methods=['GET'])
def get_workflows():
  workflows = []
  for filename in os.listdir(WORKFLOWS_DIR):
    if filename.endswith(".json"):
      workflow_id = filename[:-5]
      workflow = load_workflow(workflow_id)
      if workflow:
        workflows.append({"id": workflow_id, "name": workflow.get("name")})  # Return only ID and name
  return jsonify(workflows)

@app.route('/api/workflows/<workflow_id>', methods=['GET'])
def get_workflow_by_id(workflow_id):
  workflow = load_workflow(workflow_id)
  if workflow:
    return jsonify(workflow)
  return jsonify({"error": "Workflow not found"}), 404

@app.route('/api/workflows', methods=['POST'])
def create_workflow():
  data = request.get_json()
  workflow_id = data.get('id')
  workflow_data = data.get('data')

  save_workflow(workflow_id, workflow_data)
  return jsonify({"message": f"Workflow '{workflow_id}' created successfully"}), 201

@app.route('/api/workflows/<workflow_id>', methods=['PUT'])
def update_workflow(workflow_id):
  data = request.get_json()
  workflow_data = data.get('data')

  if not workflow_data:
    return jsonify({"error": "Workflow data is required"}), 400

  if not load_workflow(workflow_id):
    return jsonify({"error": "Workflow not found"}), 404

  save_workflow(workflow_id, data.get('data'))
  return jsonify({"message": f"Workflow '{workflow_id}' updated successfully!!"})

@app.route('/api/workflows/<workflow_id>', methods=['DELETE'])
def delete_workflow(workflow_id):
  if not load_workflow(workflow_id):
    return jsonify({"error": "Workflow not found"}), 404

  os.remove(os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json"))
  return jsonify({"message": f"Workflow '{workflow_id}' deleted successfully!!"})

def save_workflow(workflow_id, workflow_data):
  workflow_file = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
  with open(workflow_file, "w") as f:
    json.dump(workflow_data, f, indent=4)

if __name__ == '__main__':
  app.run(debug=True)