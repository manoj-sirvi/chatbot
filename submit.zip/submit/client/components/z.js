import { useState, useCallback } from 'react';
import ReactFlow, {
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  addEdge,
  Controls,
  Background,
  useReactFlow
} from 'reactflow';
import 'reactflow/dist/style.css';

const nodeTypes = {
  message: ({ data }) => (
    <div className="custom-node">
      📩 {data.label}
    </div>
  ),
  action: ({ data }) => (
    <div className="custom-node">
      ⚡ {data.label}
    </div>
  ),
  filter: ({ data }) => (
    <div className="custom-node">
      🎚️ {data.label}
    </div>
  ),
};

const FlowBuilder = () => {
  const { project } = useReactFlow();
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // Connection handler
  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  // Drag & Drop handlers
  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const type = event.dataTransfer.getData('application/reactflow');
      const label = event.dataTransfer.getData('label');

      // Get position where node should be placed
      const position = project({
        x: event.clientX - 250, // Adjust for sidebar width
        y: event.clientY - 50,  // Adjust for header height
      });

      const newNode = {
        id: `${Date.now()}`,
        type,
        position,
        data: { label },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [project, setNodes]
  );

  return (
    <div className="dndflow">
      <aside className="sidebar">
        <div className="description">Drag these nodes:</div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'message');
          e.dataTransfer.setData('label', 'Message');
        }}>
          📩 Message
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'action');
          e.dataTransfer.setData('label', 'Action');
        }}>
          ⚡ Action
        </div>
        <div className="dndnode" draggable onDragStart={(e) => {
          e.dataTransfer.setData('application/reactflow', 'filter');
          e.dataTransfer.setData('label', 'Filter');
        }}>
          🎚️ Filter
        </div>
      </aside>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        fitView
      >
        <Controls />
        <Background />
      </ReactFlow>
    </div>
  );
};

export default function App() {
  return (
    <ReactFlowProvider>
      <FlowBuilder />
    </ReactFlowProvider>
  );
}