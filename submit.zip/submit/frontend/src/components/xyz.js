import React, { useState, useRef, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Draggable from 'react-draggable';
import axios from 'axios';
import './xyz.css';

const WorkflowBuilder = () => {
  const [elements, setElements] = useState([]);
  const [selectedElementId, setSelectedElementId] = useState(null);
  const workflowCanvasRef = useRef(null);
  const [workflowName, setWorkflowName] = useState('');
  const [keywords, setKeywords] = useState([]);
  const [newKeyword, setNewKeyword] = useState('');
  const nodeRefs = useRef({});

  const addElement = (type, x, y) => {
    setElements([...elements, { id: uuidv4(), type, position: { x, y }, data: {}, connections: [] }]);
  };

  const handleDrag = (e, data, id) => {
    setElements(els =>
      els.map(el => (el.id === id ? { ...el, position: { x: data.x, y: data.y } } : el))
    );
  };

  const handleElementClick = (id) => {
    setSelectedElementId(id);
  };

  const handleMessageChange = (id, text) => {
    setElements(els =>
      els.map(el => (el.id === id ? { ...el, data: { ...el.data, text } } : el))
    );
  };

  const handleButtonLabelChange = (id, label) => {
    setElements(els =>
      els.map(el => (el.id === id ? { ...el, data: { ...el.data, label } } : el))
    );
  };

  const handleButtonActionChange = (id, action) => {
    setElements(els =>
      els.map(el => (el.id === id ? { ...el, data: { ...el.data, action } } : el))
    );
  };

  const handleActionChange = (id, actionType) => {
    setElements(els =>
      els.map(el => (el.id === id ? { ...el, data: { ...el.data, actionType } } : el))
    );
  };

  const handleAddKeyword = () => {
    if (newKeyword.trim()) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword('');
    }
  };

  const handleDeleteKeyword = (keywordToDelete) => {
    setKeywords(keywords.filter(keyword => keyword !== keywordToDelete));
  };

  const handleSaveWorkflow = async () => {
    if (workflowName.trim() && elements.some(el => el.type === 'message')) {
      const workflowData = {
        name: workflowName,
        keywords: keywords,
        elements: elements,
      };
      try {
        await axios.post('http://localhost:5000/api/workflows', { id: workflowName.replace(/\s+/g, '_'), data: workflowData });
        alert(`Workflow "${workflowName}" saved!`);
      } catch (error) {
        console.error('Error saving workflow:', error);
        alert('Error saving workflow.');
      }
    } else {
      alert('Please give your workflow a name and ensure at least one Message element is present.');
    }
  };

  const renderElement = (element) => {
    const isSelected = selectedElementId === element.id;
    const onClick = () => handleElementClick(element.id);

    switch (element.type) {
      case 'start':
        return <StartElement key={element.id} {...element} onClick={onClick} isSelected={isSelected} />;
      case 'message':
        return (
          <MessageElement
            key={element.id}
            {...element}
            onChange={(text) => handleMessageChange(element.id, text)}
            onClick={onClick}
            isSelected={isSelected}
          />
        );
      case 'button':
        return (
          <ButtonElement
            key={element.id}
            {...element}
            onLabelChange={(label) => handleButtonLabelChange(element.id, label)}
            onActionChange={(action) => handleButtonActionChange(element.id, action)}
            onClick={onClick}
            isSelected={isSelected}
          />
        );
      case 'action':
        return (
          <ActionElement
            key={element.id}
            {...element}
            onChange={(actionType) => handleActionChange(element.id, actionType)}
            onClick={onClick}
            isSelected={isSelected}
          />
        );
      default:
        return null;
    }
  };


  const StartElement = ({ position, onClick, isSelected }) => (
    <div
      className={`workflow-element start ${isSelected ? 'selected' : ''}`}
      style={{ ...position, backgroundColor: 'green' }}
      onClick={onClick}
    >
      Start
    </div>
  );

  const MessageElement = ({ position, data, onChange, onClick, isSelected }) => (
    <div
      className={`workflow-element message ${isSelected ? 'selected' : ''}`}
      style={position}
      onClick={onClick}
    >
      Message
      {isSelected && (
        <input
          type="text"
          placeholder="Message Text"
          value={data.text || ''}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
    </div>
  );

  const ButtonElement = ({ position, data, onLabelChange, onActionChange, onClick, isSelected }) => (
    <div
      className={`workflow-element button ${isSelected ? 'selected' : ''}`}
      style={position}
      onClick={onClick}
    >
      Button
      {isSelected && (
        <div>
          <input
            type="text"
            placeholder="Button Label"
            value={data.label || ''}
            onChange={(e) => onLabelChange(e.target.value)}
          />
          <input
            type="text"
            placeholder="Button Action"
            value={data.action || ''}
            onChange={(e) => onActionChange(e.target.value)}
          />
        </div>
      )}
    </div>
  );

  const ActionElement = ({ position, data, onChange, onClick, isSelected }) => (
    <div
      className={`workflow-element action ${isSelected ? 'selected' : ''}`}
      style={position}
      onClick={onClick}
    >
      Action
      {isSelected && (
        <select value={data.actionType || ''} onChange={(e) => onChange(e.target.value)}>
          <option value=""> Action</option>
          <option value="set_variable"> Variable</option>
          <option value="send_email">Email</option>
        </select>
      )}
    </div>
  );

  return (
    <div className="workflow-builder">
      <h2>Workflow Builder</h2>
      <div className="workflow-controls">
        <input
          type="text"
          placeholder="Workflow Name"
          value={workflowName}
          onChange={(e) => setWorkflowName(e.target.value)}
        />
        <div>
          <input
            type="text"
            placeholder="Add Keyword"
            value={newKeyword}
            onChange={(e) => setNewKeyword(e.target.value)}
          />
          <button onClick={handleAddKeyword}>Add</button>
        </div>
        <div>
          Keywords:
          {keywords.map(keyword => (
            <span key={keyword}>
              {keyword}
              <button onClick={() => handleDeleteKeyword(keyword)}>X</button>
            </span>
          ))}
        </div>
        <button onClick={handleSaveWorkflow}>Save Workflow</button>
      </div>

      <div className="element-palette">
        <button onClick={() => addElement('start', 50, 50)}>Start</button>
        <button onClick={() => addElement('message', 50, 150)}>Message</button>
        <button onClick={() => addElement('button', 50, 250)}>Button</button>
        <button onClick={() => addElement('action', 50, 350)}>Action</button>
      </div>

      <div className="workflow-canvas" ref={workflowCanvasRef} onDrop={(e) => e.preventDefault()} onDragOver={(e) => e.preventDefault()}>
        {elements.map(element => {
         if (!nodeRefs.current[element.id]) {
          nodeRefs.current[element.id] = React.createRef()
        }
        const ref = nodeRefs.current[element.id];
        return (
          <Draggable
            key={element.id}
            position={element.position}
            onDrag={(e, data) => handleDrag(e, data, element.id)}
            nodeRef={nodeRefs.current[element.id]}
          >
            <div ref={ref}>
              {renderElement(element)}
            </div>
          </Draggable>
        );
      })}
        {elements.map(source =>
          source.connections.map(targetId => {
            const target = elements.find(el => el.id === targetId);
            if (target) {
              return (
                <div
                  key={`${source.id}-${targetId}`}
                  className="connection"
                  style={{

                  }}
                />
              );
            }
            return null;
          })
        )}
      </div>
    </div>
  );
};

export default WorkflowBuilder;